﻿const produtos = [
  {
    "id": 1,
    "nome": "Árvore Nordica 180 cm",
    "categoria": "Árvores",
    "descricao": "Árvore de silhueta elegante, com galhos densos e acabamento natural.",
    "preco": 899.9,
    "imagem": "file:///C:/Users/bruno_parquiardi/Downloads/Av2%20-%20WEb/Av2%20-%20Website/images/%C3%81rvore%20Nordica%20180%20cm.jpg",
    "colecao": "Essenciais de Inverno",
    "destaque": true
  },
  {
    "id": 2,
    "nome": "Árvore Alba 150 cm",
    "categoria": "Árvores",
    "descricao": "Uma versão compacta para composições delicadas e ambientes menores.",
    "preco": 649.9,
    "imagem": "file:///C:/Users/bruno_parquiardi/Downloads/Av2%20-%20WEb/Av2%20-%20Website/images/%C3%81rvore%20Alba%20150%20cm.jpg",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 3,
    "nome": "Árvore Flocada Aspen",
    "categoria": "Árvores",
    "descricao": "Galhos com efeito de neve para uma paisagem de inverno dentro de casa.",
    "preco": 1190.0,
    "imagem": "file:///C:/Users/bruno_parquiardi/Downloads/Av2%20-%20WEb/Av2%20-%20Website/images/%C3%81rvore%20Flocada%20Aspen.jpg",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 4,
    "nome": "Mini Árvore Pinheiro",
    "categoria": "Árvores",
    "descricao": "Peça artesanal para aparadores, mesas laterais e pequenos cantos.",
    "preco": 189.9,
    "imagem": "https://hips.hearstapps.com/hmg-prod/images/screen-shot-2022-11-14-at-4-09-18-pm-1668460160.png?crop=1xw%3A1xh%3Bcenter",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 5,
    "nome": "Árvore Slim Lumière",
    "categoria": "Árvores",
    "descricao": "Formato estreito, ideal para espaços urbanos sem perder a presença.",
    "preco": 759.9,
    "imagem": "https://hips.hearstapps.com/hmg-prod/images/screen-shot-2022-11-14-at-4-09-18-pm-1668460160.png?crop=1xw%3A1xh%3Bcenter",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 6,
    "nome": "Conjunto de Bolas Âmbar",
    "categoria": "Bolas e Enfeites",
    "descricao": "Seis esferas em vidro com reflexos quentes e acabamento acetinado.",
    "preco": 129.9,
    "imagem": "https://glassiera.com/cdn/shop/files/il_1588xN.7215841808_tj6p.avif?crop=center&height=1200&v=1759789244&width=1200",
    "colecao": "Noite Dourada",
    "destaque": true
  },
  {
    "id": 7,
    "nome": "Bolas Vinho Heritage",
    "categoria": "Bolas e Enfeites",
    "descricao": "Conjunto de oito peças em tom vinho profundo com textura fosca.",
    "preco": 149.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 8,
    "nome": "Esferas Champagne",
    "categoria": "Bolas e Enfeites",
    "descricao": "Acabamento metálico suave para uma árvore luminosa e atemporal.",
    "preco": 119.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 9,
    "nome": "Enfeite Estrela Aurora",
    "categoria": "Bolas e Enfeites",
    "descricao": "Estrela de topo com detalhes delicados e brilho discreto.",
    "preco": 89.9,
    "imagem": "https://glassiera.com/cdn/shop/files/il_1588xN.7215841808_tj6p.avif?crop=center&height=1200&v=1759789244&width=1200",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 10,
    "nome": "Pingentes de Cristal",
    "categoria": "Bolas e Enfeites",
    "descricao": "Trio de pingentes transparentes que refletem a luz dos ambientes.",
    "preco": 79.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 11,
    "nome": "Guirlanda Bosque 45 cm",
    "categoria": "Guirlandas",
    "descricao": "Folhagens verdes e pinhas naturais em composição abundante.",
    "preco": 249.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Essenciais de Inverno",
    "destaque": true
  },
  {
    "id": 12,
    "nome": "Guirlanda Rubra",
    "categoria": "Guirlandas",
    "descricao": "Laço de veludo vinho e pequenos frutos vermelhos em base natural.",
    "preco": 289.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 13,
    "nome": "Guirlanda Neve Serena",
    "categoria": "Guirlandas",
    "descricao": "Folhagens claras com acabamento nevado e presença delicada.",
    "preco": 269.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 14,
    "nome": "Guirlanda Eucalipto",
    "categoria": "Guirlandas",
    "descricao": "Uma leitura contemporânea do Natal, com folhagens de tons suaves.",
    "preco": 219.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 15,
    "nome": "Guirlanda Dourada 60 cm",
    "categoria": "Guirlandas",
    "descricao": "Ramos metalizados em dourado envelhecido para portas e paredes.",
    "preco": 329.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 16,
    "nome": "Vela Canela & Cedro",
    "categoria": "Velas",
    "descricao": "Aroma acolhedor de especiarias e madeira em copo de vidro âmbar.",
    "preco": 89.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Natal Clássico",
    "destaque": true
  },
  {
    "id": 17,
    "nome": "Vela Floresta Branca",
    "categoria": "Velas",
    "descricao": "Notas verdes e frescas inspiradas em uma manhã de inverno.",
    "preco": 94.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 18,
    "nome": "Vela Baunilha Bourbon",
    "categoria": "Velas",
    "descricao": "Baunilha cremosa com fundo amadeirado e queima uniforme.",
    "preco": 84.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 19,
    "nome": "Dupla de Velas Pilar",
    "categoria": "Velas",
    "descricao": "Duas velas marfim de alturas diferentes para centros de mesa.",
    "preco": 69.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 20,
    "nome": "Vela Noite de Natal",
    "categoria": "Velas",
    "descricao": "Fragrância de laranja, cravo e pinho em edição especial.",
    "preco": 109.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 21,
    "nome": "CastIçal Dourado Antigo",
    "categoria": "Mesa & Casa",
    "descricao": "Peça metálica de linhas clássicas para iluminar a mesa posta.",
    "preco": 159.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Noite Dourada",
    "destaque": true
  },
  {
    "id": 22,
    "nome": "Centro de Mesa Pinhal",
    "categoria": "Mesa & Casa",
    "descricao": "Composição decorativa com folhagens, pinhas e detalhes naturais.",
    "preco": 239.9,
    "imagem": "https://cdn.shopify.com/s/files/1/1552/7691/files/ralph-lauren-christmas-tablescape.png?v=1762787833",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 23,
    "nome": "Bandeja Festiva em Latão",
    "categoria": "Mesa & Casa",
    "descricao": "Bandeja de acabamento escovado para servir ou compor ambientes.",
    "preco": 179.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 24,
    "nome": "Guardanapos Bordados",
    "categoria": "Mesa & Casa",
    "descricao": "Jogo com quatro guardanapos de algodão e bordado delicado.",
    "preco": 119.9,
    "imagem": "https://cdn.shopify.com/s/files/1/1552/7691/files/ralph-lauren-christmas-tablescape.png?v=1762787833",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 25,
    "nome": "Cúpula Cenário de Inverno",
    "categoria": "Mesa & Casa",
    "descricao": "Pequena cena natalina protegida por uma cúpula de vidro.",
    "preco": 199.9,
    "imagem": "https://cdn.shopify.com/s/files/1/1552/7691/files/ralph-lauren-christmas-tablescape.png?v=1762787833",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 26,
    "nome": "Cordão Luminoso Âmbar",
    "categoria": "Iluminação",
    "descricao": "Luzes LED de tom quente para árvores, guirlandas e janelas.",
    "preco": 99.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Noite Dourada",
    "destaque": true
  },
  {
    "id": 27,
    "nome": "Microled Fio de Prata",
    "categoria": "Iluminação",
    "descricao": "Fio delicado com luzes suaves para arranjos e vasos.",
    "preco": 69.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 28,
    "nome": "Lanterna Casa de Campo",
    "categoria": "Iluminação",
    "descricao": "Lanterna decorativa com estrutura escura e luz aconchegante.",
    "preco": 229.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 29,
    "nome": "Estrela Luminosa 40 cm",
    "categoria": "Iluminação",
    "descricao": "Estrela iluminada para janelas, paredes ou composição de mesa.",
    "preco": 149.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 30,
    "nome": "Luminária Vila Natalina",
    "categoria": "Iluminação",
    "descricao": "Casario decorativo com iluminação interna em tom quente.",
    "preco": 279.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 31,
    "nome": "Caixa Presente Veludo",
    "categoria": "Presentes",
    "descricao": "Embalagem rígida revestida em veludo vinho com fita de cetim.",
    "preco": 79.9,
    "imagem": "https://glassiera.com/cdn/shop/files/il_1588xN.7215841808_tj6p.avif?crop=center&height=1200&v=1759789244&width=1200",
    "colecao": "Natal Clássico",
    "destaque": true
  },
  {
    "id": 32,
    "nome": "Kit Cartões Botânicos",
    "categoria": "Presentes",
    "descricao": "Conjunto de oito cartões ilustrados com motivos de inverno.",
    "preco": 49.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 33,
    "nome": "Fita de Cetim Champagne",
    "categoria": "Presentes",
    "descricao": "Rolo de fita premium para embrulhos e acabamentos especiais.",
    "preco": 39.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 34,
    "nome": "Meias de Lareira Bordadas",
    "categoria": "Presentes",
    "descricao": "Par de meias decorativas em tecido encorpado com bordado.",
    "preco": 139.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 35,
    "nome": "Kit Embalagem Floresta",
    "categoria": "Presentes",
    "descricao": "Papéis, etiquetas e cordão em uma paleta inspirada no bosque.",
    "preco": 89.9,
    "imagem": "https://glassiera.com/cdn/shop/files/il_1588xN.7215841808_tj6p.avif?crop=center&height=1200&v=1759789244&width=1200",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 36,
    "nome": "Pinheiro de Cerâmica",
    "categoria": "Artesanais",
    "descricao": "Escultura artesanal com esmalte verde profundo.",
    "preco": 119.9,
    "imagem": "https://hips.hearstapps.com/hmg-prod/images/screen-shot-2022-11-14-at-4-09-18-pm-1668460160.png?crop=1xw%3A1xh%3Bcenter",
    "colecao": "Essenciais de Inverno",
    "destaque": true
  },
  {
    "id": 37,
    "nome": "Casinha de Madeira",
    "categoria": "Artesanais",
    "descricao": "Peça feita à mão para criar pequenas vilas natalinas.",
    "preco": 159.9,
    "imagem": "https://cdn.shopify.com/s/files/1/1552/7691/files/ralph-lauren-christmas-tablescape.png?v=1762787833",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 38,
    "nome": "Anjo em Linho Natural",
    "categoria": "Artesanais",
    "descricao": "Enfeite têxtil com acabamento manual e tons neutros.",
    "preco": 99.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 39,
    "nome": "Pinha Dourada Decorativa",
    "categoria": "Artesanais",
    "descricao": "Pinha com banho metálico envelhecido, vendida em conjunto de três.",
    "preco": 59.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 40,
    "nome": "Soldadinho de Madeira",
    "categoria": "Artesanais",
    "descricao": "Figura clássica pintada à mão, com detalhes em vermelho e verde.",
    "preco": 189.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 41,
    "nome": "Laço de Veludo Verde",
    "categoria": "Bolas e Enfeites",
    "descricao": "Laço amplo em veludo para árvores, guirlandas e presentes.",
    "preco": 54.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 42,
    "nome": "Ramo de Azevinho",
    "categoria": "Bolas e Enfeites",
    "descricao": "Ramo decorativo com folhas verdes e pequenas bagas vermelhas.",
    "preco": 44.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 43,
    "nome": "Ponteira Floco de Neve",
    "categoria": "Bolas e Enfeites",
    "descricao": "Ponteira delicada em metal escovado com desenho vazado.",
    "preco": 99.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 44,
    "nome": "Castiçal de Vidro Canelado",
    "categoria": "Mesa & Casa",
    "descricao": "Vidro transparente com textura vertical e proporção elegante.",
    "preco": 89.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 45,
    "nome": "Jogo Americano Natural",
    "categoria": "Mesa & Casa",
    "descricao": "Conjunto de quatro peças em fibra natural trançada.",
    "preco": 129.9,
    "imagem": "https://cdn.shopify.com/s/files/1/1552/7691/files/ralph-lauren-christmas-tablescape.png?v=1762787833",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  },
  {
    "id": 46,
    "nome": "Prato Sobremesa Estrela",
    "categoria": "Mesa & Casa",
    "descricao": "Cerâmica marfim com pequeno detalhe dourado na borda.",
    "preco": 69.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 47,
    "nome": "Mini Globo de Neve",
    "categoria": "Artesanais",
    "descricao": "Globo de vidro com cenário de pinheiros e neve em movimento.",
    "preco": 139.9,
    "imagem": "https://cdn.mos.cms.futurecdn.net/7HKmRTiAsjcYUdbATWhzPA.jpg",
    "colecao": "Bosque Nevado",
    "destaque": false
  },
  {
    "id": 48,
    "nome": "Urso de Pelúcia Noel",
    "categoria": "Presentes",
    "descricao": "Pelúcia macia em tom areia com cachecol de tricô.",
    "preco": 149.9,
    "imagem": "https://cdn.shopify.com/s/files/1/0221/0041/0432/files/de4ea6829763c181e19a011deff6df8f.jpg?v=1763741428",
    "colecao": "Natal Clássico",
    "destaque": false
  },
  {
    "id": 49,
    "nome": "Árvore de Mesa Dourada",
    "categoria": "Artesanais",
    "descricao": "Escultura minimalista em metal dourado envelhecido.",
    "preco": 109.9,
    "imagem": "https://hips.hearstapps.com/hmg-prod/images/screen-shot-2022-11-14-at-4-09-18-pm-1668460160.png?crop=1xw%3A1xh%3Bcenter",
    "colecao": "Noite Dourada",
    "destaque": false
  },
  {
    "id": 50,
    "nome": "Kit Aromas de Inverno",
    "categoria": "Presentes",
    "descricao": "Trio de pequenos difusores com notas de pinho, canela e âmbar.",
    "preco": 169.9,
    "imagem": "https://www.maisonflaneur.com/cdn/shop/collections/Christmas_Baubles_7aa7bbdc-9012-4806-854b-3fe6cc306e40.png?v=1761067569",
    "colecao": "Essenciais de Inverno",
    "destaque": false
  }
];

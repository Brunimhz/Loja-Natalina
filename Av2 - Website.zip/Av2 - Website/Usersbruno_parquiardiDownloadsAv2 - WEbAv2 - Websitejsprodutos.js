﻿const normalizeText = (value = '') => value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

function getProductPalette(productName, category) {
  const name = normalizeText(productName);
  if (/vinho|bordo|vermelho|burgundy/.test(name)) return { base: '#7a2d2d', accent: '#d2a06b', light: '#f4e4d7', deep: '#3a1b1d' };
  if (/champagne|dour|ambar|ouro/.test(name)) return { base: '#d7b778', accent: '#ffebc2', light: '#f8f1dc', deep: '#6d5030' };
  if (/verde|floresta|bosque|pinheiro|azevinho|ramo|guirlanda|arvore|árvore/.test(name)) return { base: '#2b5a43', accent: '#9ec08b', light: '#edf3eb', deep: '#183a2d' };
  if (/prata|cristal|vidro|luz|estrela|lanterna|microled|fio/.test(name)) return { base: '#dfe7ee', accent: '#b8d4e6', light: '#f7f8fb', deep: '#586d7d' };
  if (/madeira|linho|natural|urso|casinha|soldado|anjo|mini|globo/.test(name)) return { base: '#ad8256', accent: '#e7cba1', light: '#f9efe5', deep: '#58402a' };
  if (/vela|fita|kit|presente|embalagem|meia|cartao|cartoes/.test(name)) return { base: '#8f5d44', accent: '#f0d29b', light: '#f7efe8', deep: '#492b1d' };
  return { base: '#173b32', accent: '#b49a67', light: '#f5efe7', deep: '#102b25' };
}

function chooseScene(productName) {
  const name = normalizeText(productName);
  if (/árvore|arvore|pinheiro|floco|neve|bosque|ramo|guirlanda/.test(name)) return 'tree';
  if (/bola|esfera|estrela|pingente|enfeite|laço|laco/.test(name)) return 'ornament';
  if (/vela|lanterna|microled|lumin|fio|cordao|cordão/.test(name)) return 'light';
  if (/presente|meia|kit|cartao|fita|caixa|embalagem/.test(name)) return 'gift';
  if (/mesa|bandeja|guardanapo|prato|cúpula|cupula|jogo|globo|castical|castiçal/.test(name)) return 'table';
  if (/madeira|anjo|soldado|casinha|urso|mini|pinha/.test(name)) return 'craft';
  return 'general';
}

function buildProductImage(product) {
  const palette = getProductPalette(product.nome, product.categoria);
  const scene = chooseScene(product.nome);
  const text = product.nome.replace(/\s+/g, ' ').trim();
  const label = (() => {
    const tokens = normalizeText(product.nome).split(' ').filter(Boolean);
    const keywords = tokens.filter((token) => token.length > 3).slice(0, 2).join(' ');
    return keywords ? keywords.toUpperCase() : 'NOËL';
  })();

  const shapes = {
    tree: `
      <g opacity="0.96">
        <path d="M240 760L340 760L300 650L240 760Z" fill="${palette.deep}" opacity="0.9"/>
        <circle cx="300" cy="420" r="120" fill="${palette.base}" opacity="0.92"/>
        <path d="M420 720L300 540L180 720H420Z" fill="${palette.base}"/>
        <path d="M430 670L300 470L170 670H430Z" fill="${palette.accent}" opacity="0.72"/>
        <path d="M380 640L300 420L220 640H380Z" fill="${palette.light}" opacity="0.32"/>
        <rect x="270" y="760" width="60" height="150" rx="18" fill="#67492d"/>
      </g>
    `,
    ornament: `
      <g opacity="0.97">
        <circle cx="310" cy="420" r="150" fill="${palette.light}" opacity="0.42"/>
        <circle cx="310" cy="420" r="120" fill="${palette.base}"/>
        <circle cx="310" cy="420" r="78" fill="${palette.accent}" opacity="0.4"/>
        <circle cx="310" cy="420" r="22" fill="${palette.light}" opacity="0.8"/>
        <path d="M220 300L310 155L400 300" stroke="${palette.accent}" stroke-width="18" fill="none" stroke-linecap="round"/>
        <path d="M215 540L310 685L405 540" stroke="${palette.accent}" stroke-width="18" fill="none" stroke-linecap="round"/>
        <path d="M150 410L10 410" stroke="${palette.accent}" stroke-width="12" stroke-linecap="round"/>
        <path d="M470 410L610 410" stroke="${palette.accent}" stroke-width="12" stroke-linecap="round"/>
      </g>
    `,
    light: `
      <g opacity="0.96">
        <rect x="190" y="300" width="230" height="420" rx="50" fill="${palette.deep}" opacity="0.18"/>
        <path d="M250 330L420 330L440 700L230 700Z" fill="${palette.accent}" opacity="0.15"/>
        <rect x="230" y="270" width="150" height="75" rx="26" fill="${palette.light}" opacity="0.88"/>
        <path d="M300 365V540" stroke="${palette.light}" stroke-width="24" stroke-linecap="round"/>
        <path d="M260 440C280 405 320 405 340 440" stroke="${palette.light}" stroke-width="18" fill="none" stroke-linecap="round"/>
        <circle cx="296" cy="562" r="38" fill="${palette.accent}" opacity="0.9"/>
        <circle cx="366" cy="562" r="38" fill="${palette.base}" opacity="0.9"/>
      </g>
    `,
    gift: `
      <g opacity="0.96">
        <rect x="180" y="330" width="260" height="250" rx="30" fill="${palette.base}"/>
        <path d="M300 330V580" stroke="${palette.light}" stroke-width="20" stroke-linecap="round"/>
        <path d="M180 450H440" stroke="${palette.light}" stroke-width="20" stroke-linecap="round"/>
        <path d="M230 300L300 190L370 300" fill="${palette.accent}" opacity="0.9"/>
        <path d="M220 300H380" stroke="${palette.accent}" stroke-width="18" stroke-linecap="round"/>
      </g>
    `,
    table: `
      <g opacity="0.96">
        <rect x="150" y="620" width="330" height="50" rx="18" fill="${palette.deep}" opacity="0.65"/>
        <rect x="220" y="330" width="200" height="190" rx="30" fill="${palette.light}" opacity="0.84"/>
        <path d="M260 320L340 208L420 320" fill="${palette.accent}" opacity="0.8"/>
        <circle cx="240" cy="420" r="28" fill="${palette.base}"/>
        <circle cx="390" cy="430" r="26" fill="${palette.accent}"/>
      </g>
    `,
    craft: `
      <g opacity="0.96">
        <rect x="160" y="640" width="300" height="30" rx="16" fill="${palette.deep}" opacity="0.65"/>
        <rect x="240" y="300" width="120" height="210" rx="20" fill="${palette.base}"/>
        <rect x="220" y="350" width="160" height="120" rx="26" fill="${palette.accent}" opacity="0.35"/>
        <path d="M240 290L300 180L360 290" fill="${palette.light}" opacity="0.88"/>
      </g>
    `,
    general: `
      <g opacity="0.96">
        <rect x="170" y="260" width="260" height="360" rx="44" fill="${palette.base}" opacity="0.85"/>
        <circle cx="300" cy="420" r="82" fill="${palette.light}" opacity="0.38"/>
        <circle cx="300" cy="420" r="32" fill="${palette.accent}" opacity="0.9"/>
      </g>
    `
  }[scene];

  const svg = `
    <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 900 1100'>
      <defs>
        <linearGradient id='bg' x1='0' x2='1' y1='0' y2='1'>
          <stop offset='0%' stop-color='${palette.light}'/>
          <stop offset='65%' stop-color='${palette.base}'/>
          <stop offset='100%' stop-color='${palette.deep}'/>
        </linearGradient>
        <radialGradient id='glow' cx='50%' cy='28%' r='55%'>
          <stop offset='0%' stop-color='${palette.accent}' stop-opacity='0.75'/>
          <stop offset='100%' stop-color='${palette.accent}' stop-opacity='0'/>
        </radialGradient>
      </defs>
      <rect width='900' height='1100' fill='url(#bg)'/>
      <rect width='900' height='1100' fill='url(#glow)'/>
      <g opacity='0.42'>
        <circle cx='120' cy='180' r='14' fill='${palette.light}'/>
        <circle cx='730' cy='220' r='12' fill='${palette.accent}'/>
        <circle cx='660' cy='870' r='16' fill='${palette.light}'/>
        <circle cx='130' cy='850' r='18' fill='${palette.accent}'/>
      </g>
      <g transform='translate(120 110)'>${shapes}</g>
      <text x='60' y='980' fill='${palette.light}' font-size='52' font-family='Georgia, serif' letter-spacing='8'>${label}</text>
      <text x='60' y='1030' fill='${palette.light}' opacity='0.78' font-size='26' font-family='Arial, sans-serif' letter-spacing='4'>${text.slice(0, 26).toUpperCase()}</text>
    </svg>
  `;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

const rawProdutos = [
  { "id": 1, "nome": "Árvore Nordica 180 cm", "categoria": "Árvores", "descricao": "Árvore de silhueta elegante, com galhos densos e acabamento natural.", "preco": 899.9, "colecao": "Essenciais de Inverno", "destaque": true },
  { "id": 2, "nome": "Árvore Alba 150 cm", "categoria": "Árvores", "descricao": "Uma versão compacta para composições delicadas e ambientes menores.", "preco": 649.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 3, "nome": "Árvore Flocada Aspen", "categoria": "Árvores", "descricao": "Galhos com efeito de neve para uma paisagem de inverno dentro de casa.", "preco": 1190.0, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 4, "nome": "Mini Árvore Pinheiro", "categoria": "Árvores", "descricao": "Peça artesanal para aparadores, mesas laterais e pequenos cantos.", "preco": 189.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 5, "nome": "Árvore Slim Lumière", "categoria": "Árvores", "descricao": "Formato estreito, ideal para espaços urbanos sem perder a presença.", "preco": 759.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 6, "nome": "Conjunto de Bolas Âmbar", "categoria": "Bolas e Enfeites", "descricao": "Seis esferas em vidro com reflexos quentes e acabamento acetinado.", "preco": 129.9, "colecao": "Noite Dourada", "destaque": true },
  { "id": 7, "nome": "Bolas Vinho Heritage", "categoria": "Bolas e Enfeites", "descricao": "Conjunto de oito peças em tom vinho profundo com textura fosca.", "preco": 149.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 8, "nome": "Esferas Champagne", "categoria": "Bolas e Enfeites", "descricao": "Acabamento metálico suave para uma árvore luminosa e atemporal.", "preco": 119.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 9, "nome": "Enfeite Estrela Aurora", "categoria": "Bolas e Enfeites", "descricao": "Estrela de topo com detalhes delicados e brilho discreto.", "preco": 89.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 10, "nome": "Pingentes de Cristal", "categoria": "Bolas e Enfeites", "descricao": "Trio de pingentes transparentes que refletem a luz dos ambientes.", "preco": 79.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 11, "nome": "Guirlanda Bosque 45 cm", "categoria": "Guirlandas", "descricao": "Folhagens verdes e pinhas naturais em composição abundante.", "preco": 249.9, "colecao": "Essenciais de Inverno", "destaque": true },
  { "id": 12, "nome": "Guirlanda Rubra", "categoria": "Guirlandas", "descricao": "Laço de veludo vinho e pequenos frutos vermelhos em base natural.", "preco": 289.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 13, "nome": "Guirlanda Neve Serena", "categoria": "Guirlandas", "descricao": "Folhagens claras com acabamento nevado e presença delicada.", "preco": 269.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 14, "nome": "Guirlanda Eucalipto", "categoria": "Guirlandas", "descricao": "Uma leitura contemporânea do Natal, com folhagens de tons suaves.", "preco": 219.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 15, "nome": "Guirlanda Dourada 60 cm", "categoria": "Guirlandas", "descricao": "Ramos metalizados em dourado envelhecido para portas e paredes.", "preco": 329.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 16, "nome": "Vela Canela & Cedro", "categoria": "Velas", "descricao": "Aroma acolhedor de especiarias e madeira em copo de vidro âmbar.", "preco": 89.9, "colecao": "Natal Clássico", "destaque": true },
  { "id": 17, "nome": "Vela Floresta Branca", "categoria": "Velas", "descricao": "Notas verdes e frescas inspiradas em uma manhã de inverno.", "preco": 94.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 18, "nome": "Vela Baunilha Bourbon", "categoria": "Velas", "descricao": "Baunilha cremosa com fundo amadeirado e queima uniforme.", "preco": 84.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 19, "nome": "Dupla de Velas Pilar", "categoria": "Velas", "descricao": "Duas velas marfim de alturas diferentes para centros de mesa.", "preco": 69.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 20, "nome": "Vela Noite de Natal", "categoria": "Velas", "descricao": "Fragrância de laranja, cravo e pinho em edição especial.", "preco": 109.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 21, "nome": "Castiçal Dourado Antigo", "categoria": "Mesa & Casa", "descricao": "Peça metálica de linhas clássicas para iluminar a mesa posta.", "preco": 159.9, "colecao": "Noite Dourada", "destaque": true },
  { "id": 22, "nome": "Centro de Mesa Pinhal", "categoria": "Mesa & Casa", "descricao": "Composição decorativa com folhagens, pinhas e detalhes naturais.", "preco": 239.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 23, "nome": "Bandeja Festiva em Latão", "categoria": "Mesa & Casa", "descricao": "Bandeja de acabamento escovado para servir ou compor ambientes.", "preco": 179.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 24, "nome": "Guardanapos Bordados", "categoria": "Mesa & Casa", "descricao": "Jogo com quatro guardanapos de algodão e bordado delicado.", "preco": 119.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 25, "nome": "Cúpula Cenário de Inverno", "categoria": "Mesa & Casa", "descricao": "Pequena cena natalina protegida por uma cúpula de vidro.", "preco": 199.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 26, "nome": "Cordão Luminoso Âmbar", "categoria": "Iluminação", "descricao": "Luzes LED de tom quente para árvores, guirlandas e janelas.", "preco": 99.9, "colecao": "Noite Dourada", "destaque": true },
  { "id": 27, "nome": "Microled Fio de Prata", "categoria": "Iluminação", "descricao": "Fio delicado com luzes suaves para arranjos e vasos.", "preco": 69.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 28, "nome": "Lanterna Casa de Campo", "categoria": "Iluminação", "descricao": "Lanterna decorativa com estrutura escura e luz aconchegante.", "preco": 229.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 29, "nome": "Estrela Luminosa 40 cm", "categoria": "Iluminação", "descricao": "Estrela iluminada para janelas, paredes ou composição de mesa.", "preco": 149.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 30, "nome": "Luminária Vila Natalina", "categoria": "Iluminação", "descricao": "Casario decorativo com iluminação interna em tom quente.", "preco": 279.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 31, "nome": "Caixa Presente Veludo", "categoria": "Presentes", "descricao": "Embalagem rígida revestida em veludo vinho com fita de cetim.", "preco": 79.9, "colecao": "Natal Clássico", "destaque": true },
  { "id": 32, "nome": "Kit Cartões Botânicos", "categoria": "Presentes", "descricao": "Conjunto de oito cartões ilustrados com motivos de inverno.", "preco": 49.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 33, "nome": "Fita de Cetim Champagne", "categoria": "Presentes", "descricao": "Rolo de fita premium para embrulhos e acabamentos especiais.", "preco": 39.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 34, "nome": "Meias de Lareira Bordadas", "categoria": "Presentes", "descricao": "Par de meias decorativas em tecido encorpado com bordado.", "preco": 139.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 35, "nome": "Kit Embalagem Floresta", "categoria": "Presentes", "descricao": "Papéis, etiquetas e cordão em uma paleta inspirada no bosque.", "preco": 89.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 36, "nome": "Pinheiro de Cerâmica", "categoria": "Artesanais", "descricao": "Escultura artesanal com esmalte verde profundo.", "preco": 119.9, "colecao": "Essenciais de Inverno", "destaque": true },
  { "id": 37, "nome": "Casinha de Madeira", "categoria": "Artesanais", "descricao": "Peça feita à mão para criar pequenas vilas natalinas.", "preco": 159.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 38, "nome": "Anjo em Linho Natural", "categoria": "Artesanais", "descricao": "Enfeite têxtil com acabamento manual e tons neutros.", "preco": 99.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 39, "nome": "Pinha Dourada Decorativa", "categoria": "Artesanais", "descricao": "Pinha com banho metálico envelhecido, vendida em conjunto de três.", "preco": 59.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 40, "nome": "Soldadinho de Madeira", "categoria": "Artesanais", "descricao": "Figura clássica pintada à mão, com detalhes em vermelho e verde.", "preco": 189.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 41, "nome": "Laço de Veludo Verde", "categoria": "Bolas e Enfeites", "descricao": "Laço amplo em veludo para árvores, guirlandas e presentes.", "preco": 54.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 42, "nome": "Ramo de Azevinho", "categoria": "Bolas e Enfeites", "descricao": "Ramo decorativo com folhas verdes e pequenas bagas vermelhas.", "preco": 44.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 43, "nome": "Ponteira Floco de Neve", "categoria": "Bolas e Enfeites", "descricao": "Ponteira delicada em metal escovado com desenho vazado.", "preco": 99.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 44, "nome": "Castiçal de Vidro Canelado", "categoria": "Mesa & Casa", "descricao": "Vidro transparente com textura vertical e proporção elegante.", "preco": 89.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 45, "nome": "Jogo Americano Natural", "categoria": "Mesa & Casa", "descricao": "Conjunto de quatro peças em fibra natural trançada.", "preco": 129.9, "colecao": "Essenciais de Inverno", "destaque": false },
  { "id": 46, "nome": "Prato Sobremesa Estrela", "categoria": "Mesa & Casa", "descricao": "Cerâmica marfim com pequeno detalhe dourado na borda.", "preco": 69.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 47, "nome": "Mini Globo de Neve", "categoria": "Artesanais", "descricao": "Globo de vidro com cenário de pinheiros e neve em movimento.", "preco": 139.9, "colecao": "Bosque Nevado", "destaque": false },
  { "id": 48, "nome": "Urso de Pelúcia Noel", "categoria": "Presentes", "descricao": "Pelúcia macia em tom areia com cachecol de tricô.", "preco": 149.9, "colecao": "Natal Clássico", "destaque": false },
  { "id": 49, "nome": "Árvore de Mesa Dourada", "categoria": "Artesanais", "descricao": "Escultura minimalista em metal dourado envelhecido.", "preco": 109.9, "colecao": "Noite Dourada", "destaque": false },
  { "id": 50, "nome": "Kit Aromas de Inverno", "categoria": "Presentes", "descricao": "Trio de pequenos difusores com notas de pinho, canela e âmbar.", "preco": 169.9, "colecao": "Essenciais de Inverno", "destaque": false }
];

const produtos = rawProdutos.map((produto) => ({
  ...produto,
  imagem: buildProductImage(produto)
}));
